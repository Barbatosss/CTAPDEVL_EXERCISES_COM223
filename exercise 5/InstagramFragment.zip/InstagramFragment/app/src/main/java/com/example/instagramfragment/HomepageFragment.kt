package com.example.instagramfragment

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment


class HomepageFragment : Fragment(R.layout.fragment_homepage) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Get the username passed from the Activity's Intent (parent activity)
        val username = activity?.intent?.getStringExtra("USERNAME_KEY")

        // Find the TextView and set the username
        val usernameTextView = view.findViewById<TextView>(R.id.textView)
        usernameTextView.text = username ?: "No username found"


    }
}
