// FakeRepository.kt
package com.example.instagramfragment

object FakeRepository {

    val usernames = mapOf(
        PostId.POST_1 to "nature_lover",
        PostId.POST_2 to "foodie_adventures",
        PostId.POST_3 to "travel_diaries",
        PostId.POST_4 to "art_gallery_official",
        PostId.POST_5 to "fitness_motivation",
        PostId.POST_6 to "photography_hub",
        PostId.POST_7 to "music_vibes",
        PostId.POST_8 to "tech_innovations",
        PostId.POST_9 to "lifestyle_blogger",
        PostId.POST_10 to "adventure_seeker"
    )

    val profilePictures = mapOf(
        PostId.POST_1 to R.drawable.profile_pic_1,
        PostId.POST_2 to R.drawable.profile_pic_2,
        PostId.POST_3 to R.drawable.profile_pic_3,
        PostId.POST_4 to R.drawable.profile_pic_4,
        PostId.POST_5 to R.drawable.profile_pic_5,
        PostId.POST_6 to R.drawable.profile_pic_6,
        PostId.POST_7 to R.drawable.profile_pic_7,
        PostId.POST_8 to R.drawable.profile_pic_8,
        PostId.POST_9 to R.drawable.profile_pic_9,
        PostId.POST_10 to R.drawable.profile_pic_10
    )

    val postImages = mapOf(
        PostId.POST_1 to R.drawable.post_image_1,
        PostId.POST_2 to R.drawable.post_image_2,
        PostId.POST_3 to R.drawable.post_image_3,
        PostId.POST_4 to R.drawable.post_image_4,
        PostId.POST_5 to R.drawable.post_image_5,
        PostId.POST_6 to R.drawable.post_image_6,
        PostId.POST_7 to R.drawable.post_image_7,
        PostId.POST_8 to R.drawable.post_image_8,
        PostId.POST_9 to R.drawable.post_image_9,
        PostId.POST_10 to R.drawable.post_image_10
    )

    val captions = mapOf(
        PostId.POST_1 to "Beautiful sunset at the mountains 🌅 #nature #photography",
        PostId.POST_2 to "Homemade pasta with fresh ingredients! 🍝 Recipe in my bio",
        PostId.POST_3 to "Exploring the ancient streets of Rome ✈️ #travel #wanderlust",
        PostId.POST_4 to "New exhibition opening this weekend! 🎨 #art #gallery",
        PostId.POST_5 to "Morning workout done! 💪 What's your fitness motivation?",
        PostId.POST_6 to "Golden hour magic ✨ Shot with my new camera setup",
        PostId.POST_7 to "Studio session vibes 🎵 New song coming soon!",
        PostId.POST_8 to "Latest tech gadget review is live! Link in bio 📱",
        PostId.POST_9 to "Sunday brunch essentials ☕️ #lifestyle #weekend",
        PostId.POST_10 to "Cliff diving in Croatia! 🏊‍♂️ #adventure #extreme"
    )

    val likesCount = mapOf(
        PostId.POST_1 to 1234,
        PostId.POST_2 to 856,
        PostId.POST_3 to 2109,
        PostId.POST_4 to 743,
        PostId.POST_5 to 967,
        PostId.POST_6 to 1876,
        PostId.POST_7 to 3421,
        PostId.POST_8 to 512,
        PostId.POST_9 to 689,
        PostId.POST_10 to 1543
    )

    val timeAgo = mapOf(
        PostId.POST_1 to "2 hours ago",
        PostId.POST_2 to "4 hours ago",
        PostId.POST_3 to "6 hours ago",
        PostId.POST_4 to "8 hours ago",
        PostId.POST_5 to "10 hours ago",
        PostId.POST_6 to "12 hours ago",
        PostId.POST_7 to "1 day ago",
        PostId.POST_8 to "1 day ago",
        PostId.POST_9 to "2 days ago",
        PostId.POST_10 to "2 days ago"
    )
}