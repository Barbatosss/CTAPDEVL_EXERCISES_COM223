package com.example.instagramfragment

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomepageFragment : Fragment(R.layout.fragment_homepage) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView: RecyclerView = view.findViewById(R.id.theBestRecyclerViewOnThePlanet)
        recyclerView.adapter = MyAdapter(createData())
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

//        val username = activity?.intent?.getStringExtra("USERNAME_KEY")
//        val usernameTextView = view.findViewById<TextView>(R.id.textView)
//        usernameTextView.text = username ?: "No username found"
    }

    private fun createData(): List<President> {
        val names = FakeRepository.presidentName
        val orders = FakeRepository.presidentOrder
        val portraits = FakeRepository.portrait

        val presidentData = ArrayList<President>()
        PresidentId.entries.forEach { presidentID ->
            if (containsId(presidentID, names, orders, portraits)) {
                presidentData.add(
                    President(
                        name = names[presidentID]!!,
                        order = orders[presidentID]!!,
                        portrait = portraits[presidentID]!!
                    )
                )
            }
        }

        return presidentData
    }

    private fun containsId(presidentID: PresidentId, vararg maps: Map<PresidentId, Any>): Boolean {
        maps.forEach {
            if (presidentID !in it.keys) return false
        }
        return true
    }
}
