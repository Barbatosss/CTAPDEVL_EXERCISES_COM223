// HomepageFragment.kt
package com.example.instagramfragment

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomepageFragment : Fragment(R.layout.fragment_homepage) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView: RecyclerView = view.findViewById(R.id.instagram_feed_recycler_view)
        recyclerView.adapter = InstagramAdapter(createInstagramPosts())
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
    }

    private fun createInstagramPosts(): List<InstagramPost> {
        val usernames = FakeRepository.usernames
        val profilePictures = FakeRepository.profilePictures
        val postImages = FakeRepository.postImages
        val captions = FakeRepository.captions
        val likesCount = FakeRepository.likesCount
        val timeAgo = FakeRepository.timeAgo

        val instagramPosts = ArrayList<InstagramPost>()

        PostId.entries.forEach { postId ->
            if (containsId(postId, usernames, profilePictures, postImages, captions, likesCount, timeAgo)) {
                instagramPosts.add(
                    InstagramPost(
                        username = usernames[postId]!!,
                        profilePicture = profilePictures[postId]!!,
                        postImage = postImages[postId]!!,
                        caption = captions[postId]!!,
                        likesCount = likesCount[postId]!!,
                        timeAgo = timeAgo[postId]!!,
                        isLiked = false, // Default to not liked
                        isBookmarked = false // Default to not bookmarked
                    )
                )
            }
        }

        return instagramPosts
    }

    private fun containsId(postId: PostId, vararg maps: Map<PostId, Any>): Boolean {
        maps.forEach { map ->
            if (postId !in map.keys) return false
        }
        return true
    }
}