// InstagramAdapter.kt
package com.example.instagramfragment

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class InstagramAdapter(
    private val posts: List<InstagramPost>
) : RecyclerView.Adapter<InstagramAdapter.PostViewHolder>() {

    inner class PostViewHolder(view: View): RecyclerView.ViewHolder(view) {
        // Header views
        val profilePicture: ImageView = view.findViewById(R.id.profile_picture)
        val username: TextView = view.findViewById(R.id.username)
        val moreOptions: ImageView = view.findViewById(R.id.more_options)

        // Post image
        val postImage: ImageView = view.findViewById(R.id.post_image)

        // Action buttons
        val likeButton: ImageView = view.findViewById(R.id.like_button)
        val commentButton: ImageView = view.findViewById(R.id.comment_button)
        val shareButton: ImageView = view.findViewById(R.id.share_button)
        val bookmarkButton: ImageView = view.findViewById(R.id.bookmark_button)

        // Post info
        val likesCount: TextView = view.findViewById(R.id.likes_count)
        val caption: TextView = view.findViewById(R.id.caption)
        val timeAgo: TextView = view.findViewById(R.id.time_ago)

        init {
            // Handle like button clicks
            likeButton.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val post = posts[position]
                    // Toggle like state
                    val newLikeState = !post.isLiked

                    // Update UI immediately
                    updateLikeButton(newLikeState)
                    updateLikesCount(post.likesCount, newLikeState)

                    // Here you would typically update your data source
                    // and notify the server about the like/unlike action
                }
            }

            // Handle bookmark button clicks
            bookmarkButton.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val post = posts[position]
                    val newBookmarkState = !post.isBookmarked
                    updateBookmarkButton(newBookmarkState)
                }
            }
        }

        private fun updateLikeButton(isLiked: Boolean) {
            likeButton.setImageResource(
                if (isLiked) R.drawable.ic_heart_filled
                else R.drawable.ic_heart_outline
            )
        }

        private fun updateBookmarkButton(isBookmarked: Boolean) {
            bookmarkButton.setImageResource(
                if (isBookmarked) R.drawable.ic_bookmark_filled
                else R.drawable.ic_bookmark_outline
            )
        }

        private fun updateLikesCount(originalCount: Int, isLiked: Boolean) {
            val newCount = if (isLiked) originalCount + 1 else originalCount - 1
            likesCount.text = "$newCount likes"
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val inflatedView: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.instagram_post_item, parent, false)
        return PostViewHolder(inflatedView)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post: InstagramPost = posts[position]

        // Bind data to views
        holder.profilePicture.setImageResource(post.profilePicture)
        holder.username.text = post.username
        holder.postImage.setImageResource(post.postImage)
        holder.likesCount.text = "${post.likesCount} likes"
        holder.caption.text = "${post.username} ${post.caption}"
        holder.timeAgo.text = post.timeAgo

        // Set initial button states
        holder.likeButton.setImageResource(
            if (post.isLiked) R.drawable.ic_heart_filled
            else R.drawable.ic_heart_outline
        )

        holder.bookmarkButton.setImageResource(
            if (post.isBookmarked) R.drawable.ic_bookmark_filled
            else R.drawable.ic_bookmark_outline
        )
    }

    override fun getItemCount(): Int {
        return posts.size
    }
}