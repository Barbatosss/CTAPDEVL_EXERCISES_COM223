package com.example.instagramfragment

import androidx.annotation.DrawableRes

data class InstagramPost(
    val username: String,
    @DrawableRes val profilePicture: Int,
    @DrawableRes val postImage: Int,
    val caption: String,
    val likesCount: Int,
    val timeAgo: String,
    val isLiked: Boolean = false,
    val isBookmarked: Boolean = false
)
