package com.example.instagramfragment

import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class NavBar : AppCompatActivity() {

    private lateinit var firstFragment: Fragment
    private var secondFragment: Fragment = ProfileFragment()

    // Launcher to pick an image for post
    private val pickImageLauncherPost = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            // Recreate the ProfileFragment with the selected image URI
            secondFragment = ProfileFragment.newInstance(it)
            setFragment(secondFragment)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_navbar)

        firstFragment = HomepageFragment()
        secondFragment = ProfileFragment()

        setFragment(firstFragment)

        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottomNavigationView)

        bottomNavigationView.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.navHome -> setFragment(firstFragment)
                R.id.navAddPost -> {
                    // Launch image picker when Add Post is tapped
                    pickImageLauncherPost.launch("image/*")
                }
                R.id.navProfile -> setFragment(secondFragment)
            }
            true
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.navbar)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun setFragment(fragment: Fragment) =
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.flFragment, fragment)
            commit()
        }
}
