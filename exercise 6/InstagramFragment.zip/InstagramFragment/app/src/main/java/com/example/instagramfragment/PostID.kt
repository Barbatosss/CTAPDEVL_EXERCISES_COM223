package com.example.instagramfragment

enum class PostId {
    POST_1, POST_2, POST_3, POST_4, POST_5, POST_6, POST_7, POST_8, POST_9, POST_10
}