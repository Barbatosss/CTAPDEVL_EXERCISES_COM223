package com.example.instagramfragment

import androidx.annotation.DrawableRes

data class President(
    val name: String,
    val order: String,
    @DrawableRes val portrait: Int
)