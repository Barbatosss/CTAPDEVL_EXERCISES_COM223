package com.example.instagramfragment

enum class PresidentId {
    FORD, CARTER, REAGAN, BUSH1, CLINTON, BUSH2, OBAMA, TRUMP1, BIDEN, TRUMP2
}