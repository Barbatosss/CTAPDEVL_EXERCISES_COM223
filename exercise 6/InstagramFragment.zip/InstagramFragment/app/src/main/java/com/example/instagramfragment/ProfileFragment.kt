package com.example.instagramfragment

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.core.net.toUri

class ProfileFragment : Fragment(R.layout.fragment_profile) {

    private lateinit var imageProfile: ImageView
    private lateinit var postImage1: ImageView

    // Launcher to select profile image
    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            imageProfile.setImageURI(it)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Get the username from intent
        val username = activity?.intent?.getStringExtra("USERNAME_KEY")

        // Initialize views
        val usernameTextView = view.findViewById<TextView>(R.id.usernameTop)
        val usernameTextView2 = view.findViewById<TextView>(R.id.username)
        imageProfile = view.findViewById(R.id.imageProfile)
        postImage1 = view.findViewById(R.id.postImage1)

        // Set username
        usernameTextView.text = username ?: "No username found"
        usernameTextView2.text = username ?: "No username found"

        // Set listener for profile image edit button
        val editPictureButton = view.findViewById<Button>(R.id.editPictureButton)
        editPictureButton.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        // Display post image passed from NavBar
        val imageUriString = arguments?.getString("POST_IMAGE_URI")
        imageUriString?.let {
            val imageUri = it.toUri()
            postImage1.setImageURI(imageUri)
        }
    }

    companion object {
        fun newInstance(postImageUri: Uri?): ProfileFragment {
            val fragment = ProfileFragment()
            val bundle = Bundle().apply {
                putString("POST_IMAGE_URI", postImageUri.toString())
            }
            fragment.arguments = bundle
            return fragment
        }
    }
}
