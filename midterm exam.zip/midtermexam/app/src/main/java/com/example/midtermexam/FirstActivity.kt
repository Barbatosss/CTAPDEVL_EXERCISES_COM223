package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class FirstActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.first_activity)

        // Apply system window insets to root view
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.first)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val plainTexteditText = findViewById<EditText>(R.id.typeText)
        val nextButton = findViewById<Button>(R.id.button)

        nextButton.setOnClickListener {
            val typeText = plainTexteditText.text.toString()

                val intent = Intent(this, SecondActivity::class.java)
                intent.putExtra("PLAIN_KEY", typeText)
                startActivity(intent)
        }

    }

    public override fun onStart() {
        super.onStart()
        Log.d("1st activity", "Activity 1 has started")
    }

    public override fun onResume() {
        super.onResume()
        Log.d("1st Activity", "Activity 1 has resumed")
    }
    public override fun onPause() {
        super.onPause()
        Log.d("1st Activity", "Activity 1 has paused")
    }

    public override fun onStop() {
        super.onStop()
        Log.d("1st Activity", "Activity 1 has stopped")

    }

    public override fun onDestroy() {
        super.onDestroy()
        Log.d("1st Activity", "Activity 1 has stopped")
    }
}
