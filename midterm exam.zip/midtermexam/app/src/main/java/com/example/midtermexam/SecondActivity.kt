package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_activity)

        val typeText = intent.getStringExtra("PLAIN_KEY")
        // Find the TextView where you want to display the username
        val plainTextEditText = findViewById<TextView>(R.id.secondDisplay)
        plainTextEditText.text = typeText ?: "No text found" // Fallback text if username is null


        val plainTexteditText2 = findViewById<EditText>(R.id.editTextText2)
        val nextButton = findViewById<Button>(R.id.button2)

        nextButton.setOnClickListener {
            val typeText2 = plainTexteditText2.text.toString()

            val intent = Intent(this, ThirdActivity::class.java)
            intent.putExtra("PLAIN_KEY", typeText2)
            startActivity(intent)
        }
    }
    public override fun onStart() {
        super.onStart()
        Log.d("2nd activity", "Activity 2 has started")
    }

    public override fun onResume() {
        super.onResume()
        Log.d("2nd Activity", "Activity 2 has resumed")
    }
    public override fun onPause() {
        super.onPause()
        Log.d("2nd Activity", "Activity 2 has paused")
    }

    public override fun onStop() {
        super.onStop()
        Log.d("2nd Activity", "Activity 2 has stopped")

    }

    public override fun onDestroy() {
        super.onDestroy()
        Log.d("2nd Activity", "Activity 2 has stopped")
    }
}
