package com.example.myapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ThirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.third_activity)

        val typeText = intent.getStringExtra("PLAIN_KEY")
        val plainTextEditText = findViewById<TextView>(R.id.textView3)
        plainTextEditText.text = typeText ?: "No text found"

        val nextButton = findViewById<Button>(R.id.button3)

        nextButton.setOnClickListener {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/Barbatosss"))
            startActivity(i)
        }

    }
    public override fun onStart() {
        super.onStart()
        Log.d("3rd activity", "Activity 3 has started")
    }

    public override fun onResume() {
        super.onResume()
        Log.d("3rd Activity", "Activity 3 has resumed")
    }
    public override fun onPause() {
        super.onPause()
        Log.d("3rd Activity", "Activity 3 has paused")
    }

    public override fun onStop() {
        super.onStop()
        Log.d("3rd Activity", "Activity 3 has stopped")

    }

    public override fun onDestroy() {
        super.onDestroy()
        Log.d("3rd Activity", "Activity 3 has stopped")
    }
}
